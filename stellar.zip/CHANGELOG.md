# CHANGELOG.md

## [3.0.0] - 2025-02-04

- Upgrade to Tailwind 4
- Update other dependencies

## [2.2.0] - 2024-12-08

- Update dependencies + Upgrade to Next.js 15

## [2.1.5] - 2024-11-30

- Fix MDX content not rendering

## [2.1.4] - 2024-11-03

- Update Hamburger button

## [2.1.3] - 2024-10-26

- Update dependencies
- Use CSS only for clients carousel

## [2.1.1] - 2024-07-09

- Minor improvements

## [2.1.0] - 2024-07-05

- Replace Contentlayer with MDX

## [2.0.0] - 2023-12-11

- Added 7 new pages
- Update Next.js to 14

## [1.1.2] - 2023-10-04

- Update Twitter icon
- Update dependencies

## [1.1.0] - 2023-06-20

- Fix issue with Google Fonts

## [1.0.3] - 2023-05-15

- Fix issue with clients carousel

## [1.0.2] - 2023-05-06

- Dependencies update

## [1.0.1] - 2023-05-06

- Dependencies update

## [1.0.0] - 2023-04-19

First release
